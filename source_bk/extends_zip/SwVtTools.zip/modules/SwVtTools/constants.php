<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefan Warnat <support@stefanwarnat.de>
 * Date: 24.07.14 14:59
 * You must not use this file without permission.
 */

define("CACHE_DIR", dirname(__FILE__).DIRECTORY_SEPARATOR."cache/");