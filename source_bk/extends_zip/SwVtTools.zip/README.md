VtigerCRM-Tools
===============

**VtigerCRM Extension from [Stefan Warnat](https://vtiger.stefanwarnat.de)**

Compatible to VtigerCRM 6.0, 6.1 and 6.2

for more information go to this page: https://shop.stefanwarnat.de/vtigercrm-tools/
