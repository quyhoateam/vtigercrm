<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'LBL_ADD_RECORD' => 'Thêm bản mẫu Email',
	'SINGLE_EmailTemplates' => 'Bản mẫu Email',
	'LBL_EMAIL_TEMPLATES'=> 'Những bản mẫu Email',
	'LBL_EMAIL_TEMPLATE' => 'Bản mẫu Email',
	
	'LBL_TEMPLATE_NAME' => 'Tên Bản mẫu Email',
	'LBL_DESCRIPTION' => 'Mô tả',
	'LBL_SUBJECT' => 'Tiêu đề',
	'LBL_GENERAL_FIELDS' => 'Những Field chung',
	'LBL_SELECT_FIELD_TYPE' => 'Chọn loại Field',
	
	'LBL_EMAIL_TEMPLATE_DESCRIPTION'=>'Quản lý mẫu E-Mail module',
	
);
