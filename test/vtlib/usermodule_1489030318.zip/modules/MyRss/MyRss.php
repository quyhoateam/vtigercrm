<?php

class MyRss {
        function vtlib_handler($moduleName, $eventType) {
                if ($eventType == 'module.postinstall') {
                        $data = array('url' => 'https://www.vtiger.com/blogs/?feed=rss2',
                                    'title' => 'Vtiger Blogs');
                                MyRss_Record_Model::create($data);
                }
        }
}